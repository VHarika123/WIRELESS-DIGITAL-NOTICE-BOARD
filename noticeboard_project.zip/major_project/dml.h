void display_char(unsigned char ch,unsigned int delay);
void display_str(unsigned char *ch,unsigned int delay);
