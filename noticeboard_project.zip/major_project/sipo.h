void Init_74LS164(void);
void SIPO_74LS164_1(unsigned char sDat); //Serial In Parallel Out(SIPO) Operations
void SIPO_74LS164_2(unsigned char sDat); //Serial In Parallel Out(SIPO) Operations
void SIPO_74LS164_3(unsigned char sDat); //Serial In Parallel Out(SIPO) Operations
void SIPO_74LS164_4(unsigned char sDat); //Serial In Parallel Out(SIPO) Operations

