#include<LPC21xx.h>
#include<stdlib.h>
#include<string.h>

#include "types.h"
#include "delay.h"
#include "defines2.h"
#include "uart.h"
#include "i2c.h"
#include "i2c_eeprom.h"
#include "i2c_defines.h"
#include "lcd.h"
#include "device.h"

#define PREINT_VAL ((PCLK/32768)-1)
#define PREFRAC_VAL (PCLK-((PREINT + 1) * 32768))

#define BUZZ 20 // P0.20

u8 d_pass[5]="1234",r_pass[5],a[5];
extern char buff[100];
extern unsigned char i,r_flag;
extern u8 i_flag;
u32 otp;

void buzzer(void);
void myitoa(u32,u8 *);
void change_password(void);
void Enable_EINT1(void);

main()
{
	PREINT=PREINT_VAL;
	PREFRAC=PREFRAC_VAL;
	CCR=0X01;
	SEC=10;
	InitUART0();
	init_i2c();
	InitLCD();
	Enable_EINT1();
	SETBIT(IODIR0,BUZZ);
	//i2c_eeprom_page_write(I2C_SADDR,PASS_ADDR,d_pass,4);
	i2c_eeprom_seq_read(I2C_SADDR,PASS_ADDR,r_pass,4);
	delay_ms(1000);
	StrLCD("   WELCOME TO   ");
	CmdLCD(0XC0);
	StrLCD("  MAJOR PROJECT ");
	delay_ms(2000);
	CmdLCD(0x01);
	while(1)
	{
		memset(buff,'\0',100);
		CmdLCD(0x80);
		r_flag=0;
		i_flag=0;
		i=0;
		StrLCD("Enter the pass:");
		CmdLCD(0xc0);	
		while((r_flag==0)&&(i_flag==0));
		if(r_flag==1)
		{
		r_flag=0;
		i=0;
		StrLCD((s8 *)buff);
		delay_ms(1000);
		CmdLCD(0x01);
		StrLCD("Validating");
		for(i=10;i<16;i++)
		{
			CharLCD('.');
			delay_ms(50);
		}
		delay_ms(1000);
		if(strcmp((const char *)buff,(const char *)r_pass)==0)
		{
			CmdLCD(0x01);
			StrLCD("Valid pass ");
			delay_ms(1000);
			CmdLCD(0x01);
			srand(SEC);
			otp=rand()%(9999-1000)+1000;
			myitoa(otp,a);
			delay_ms(1000);
			UART0_Str((char *)a);
			UART0_Str("\r\n");
			delay_ms(1000);
			memset(buff,'\0',100);
			i=0,r_flag=0;
			while(r_flag==0);
			StrLCD((s8 *)buff);
			delay_ms(1000);
			CmdLCD(0x01);
			StrLCD("Validating");
			for(i=10;i<16;i++)
			{
				CharLCD('.');
				delay_ms(50);
			}	
			if(otp==atoi(buff))
			{
				CmdLCD(0x01);
				StrLCD("Valid OTP ");
				delay_ms(1000);
				motor();
				CmdLCD(0x01);
					
			}			
			else
			{
				CmdLCD(0x01);
				StrLCD("Invalid OTP ");
				delay_ms(1000);
				buzzer();
				CmdLCD(0x01);	
			}
		}
		else
		{
			CmdLCD(0x01);
			StrLCD("Invalid pass ");
			delay_ms(1000);
			buzzer();
			CmdLCD(0x01);	
		}
		}
		else if(i_flag==1)
		{
			change_password();
			i_flag=0;
			i=0;  
		}
	}
}

void buzzer(void)
{
	u32 cnt=0;
	while(cnt<5)
	{
		SETBIT(IOPIN0,BUZZ);
		delay_ms(1000);
		CLRBIT(IOPIN0,BUZZ);
		delay_ms(1000);
		cnt++;
	}
}

void myitoa(u32 n,u8 *s)
{
	u32 j=0,temp;
	temp=n;
	while(temp)
	{
		temp/=10;
		j++;
	}
	s[j--]='\0';
	while(n)
	{
		s[j--]=n%10+48;
		n/=10;
	}
	//return a;
}
